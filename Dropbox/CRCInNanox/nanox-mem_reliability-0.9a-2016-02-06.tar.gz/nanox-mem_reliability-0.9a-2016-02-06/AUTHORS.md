**Back to:** [README](README.md) >

Nanos++ RTL code contributors (including external collaborations)
=================================================================

* Alejandro Duran              Barcelona Supercomputing Center
* Luis Martinell               Barcelona Supercomputing Center
* Xavier Teruel                Barcelona Supercomputing Center
* Carlo Bertinolli             University of Pisa
* Judit Planas                 Barcelona Supercomputing Center
* Javier Bueno                 Barcelona Supercomputing Center
* Guillermo Miranda            Barcelona Supercomputing Center
* Ananya Muddukrishna          KTH Royal Institute of Technology
* Artur Podobas                KTH Royal Institute of Technology
* Jose M. Perez                Barcelona Supercomputing Center
* Victor Lopez                 Barcelona Supercomputing Center
* Marta Garcia                 Barcelona Supercomputing Center
* Antonio Filgueras            Barcelona Supercomputing Center
* Florentino Sainz             Barcelona Supercomputing Center
* Jorge Bellon                 Barcelona Supercomputing Center
* Roger Ferrer                 Barcelona Supercomputing Center
* Sara Royuela                 Barcelona Supercomputing Center
* Kallia Chronaki              Barcelona Supercomputing Center
* Diego Nieto                  Barcelona Supercomputing Center
* Sergi Mateo                  Barcelona Supercomputing Center
* Jan Ciesko                   Barcelona Supercomputing Center

