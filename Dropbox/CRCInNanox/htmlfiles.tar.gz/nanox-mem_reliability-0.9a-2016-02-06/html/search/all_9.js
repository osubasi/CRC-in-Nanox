var searchData=
[
  ['workdescriptor',['WorkDescriptor',['../classWorkDescriptor.html',1,'']]],
  ['workdescriptor_2ecpp',['workdescriptor.cpp',['../workdescriptor_8cpp.html',1,'']]]
];
