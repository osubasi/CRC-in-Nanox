var searchData=
[
  ['readme_2emd',['README.md',['../README_8md.html',1,'']]],
  ['restore',['restore',['../classnanos_1_1System.html#ac58802e2588abdbb698dca9d078c8505',1,'nanos::System']]]
];
