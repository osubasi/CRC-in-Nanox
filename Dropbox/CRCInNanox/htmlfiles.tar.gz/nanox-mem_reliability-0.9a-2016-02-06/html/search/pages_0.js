var searchData=
[
  ['authors',['AUTHORS',['../md_AUTHORS.html',1,'']]]
];
