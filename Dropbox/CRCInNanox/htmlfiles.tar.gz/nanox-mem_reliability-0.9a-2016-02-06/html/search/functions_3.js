var searchData=
[
  ['getcrc32',['getCRC32',['../classnanos_1_1System.html#a30118dd6c3d76f017f16bf74812fd196',1,'nanos::System']]]
];
