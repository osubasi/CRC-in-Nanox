var searchData=
[
  ['authors_2emd',['AUTHORS.md',['../AUTHORS_8md.html',1,'']]]
];
