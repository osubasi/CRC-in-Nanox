/*************************************************************************************/
/*      Copyright 2015 Barcelona Supercomputing Center                               */
/*                                                                                   */
/*      This file is part of the NANOS++ library.                                    */
/*                                                                                   */
/*      NANOS++ is free software: you can redistribute it and/or modify              */
/*      it under the terms of the GNU Lesser General Public License as published by  */
/*      the Free Software Foundation, either version 3 of the License, or            */
/*      (at your option) any later version.                                          */
/*                                                                                   */
/*      NANOS++ is distributed in the hope that it will be useful,                   */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of               */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                */
/*      GNU Lesser General Public License for more details.                          */
/*                                                                                   */
/*      You should have received a copy of the GNU Lesser General Public License     */
/*      along with NANOS++.  If not, see <http://www.gnu.org/licenses/>.             */
/*************************************************************************************/

#ifndef _NANOS_SYSTEM_DECL_H
#define _NANOS_SYSTEM_DECL_H

#include "processingelement_decl.hpp"
#include "throttle_decl.hpp"
#include "schedule_decl.hpp"
#include "threadteam_decl.hpp"
#include "slicer_decl.hpp"
#include "worksharing_decl.hpp"
#include "nanos-int.h"
#include "dataaccess_fwd.hpp"
#include "instrumentation_decl.hpp"
#include "network_decl.hpp"
#include "pminterface_decl.hpp"
#include "plugin_decl.hpp"
#include "archplugin_decl.hpp"
#include "barrier_decl.hpp"
#include "accelerator_decl.hpp"
#include "location_decl.hpp"
#include "addressspace_decl.hpp"
#include "smpbaseplugin_decl.hpp"
#include "hwloc_decl.hpp"
#include "threadmanager_decl.hpp"
#include "router_decl.hpp"
#include "clustermpiplugin_fwd.hpp"

#include "newregiondirectory_decl.hpp"
#include "smpdevice_decl.hpp"

#ifdef GPU_DEV
#include "pinnedallocator_decl.hpp"
#include "gpuprocessor_fwd.hpp"
#endif

#ifdef OpenCL_DEV
#include "openclprocessor_fwd.hpp"
#endif

#ifdef NANOS_INSTRUMENTATION_ENABLED
#include "mainfunction_fwd.hpp"
#endif

#include <vector>
#include <string>

#ifdef NANOS_RESILIENCY_ENABLED
#include "hashmap.hpp"
#endif
/*! \mainpage CRC Implementation Main Page
 *
 * CRC Implementation is integrated with Jorge Bellon’s resiliency version.
 *   Main CRC functionality is in system.cpp and system_decl.hpp under src/core/ directory.
 *  Two types of CRC computation are implemented:
 *	- Hardware-accelerated 
 *	- Software-only
 * 
 * Runtime checks whether the underlying architecture supports the Intel CRC instructions and automatically chooses between the hardware-accelerated and 
 * software-only implementations in the beginning of the execution.
 * 
 * The environment flag “--enable-crc=yes” enables CRC mechanism.
 * 
 * The Nanox configuration call has to include “CXXFLAG=-march=native” for CRC instructions. 
 * 
 * The implementation is tested with
 *	- Sample program written for CRC mechanism features such as initialization, recovery.
 *	- OmpSs Benchmarks (Both SMP and OmpSs+MPI).
 *
 * The source code is available at OmpSs downloads website (https://pm.bsc.es/ompss-downloads) and the direct link is
 *      - https://pm.bsc.es/sites/default/files/ftp/nanox/ad-hoc/nanox-mem_reliability-0.9a-2016-02-06.tar.gz
 * 
 *
 * \section implement_sec Implementation Details
 *  - The implementation relies heavily on previously implemented resiliency mechanism in Nanox. 
 *    For instance, error recovery is completely done through the resiliency mechanism, no new snapshots are taken.
 *  
 *  - It introduces very few data structures in system_decl.hpp and a number of functions residing in system.cpp.
 *  
 *  - Rest of the implementation extends to smpdd.cpp under src/arch/ directory and workdescriptor.cpp under src/core directory.
 *  
 *  - Runtime flag is implemented for enabling of the CRC mechanism.
 * 
 *  - The main functionality resides in system.cpp.
 */

/*! Namespace Nanos  */
namespace nanos {


/*! System Class
 * The main class for the execution initialization, continuation and finalization. It also maintains global variables and information needed for the computation.
 */
   class System
   {
      public:
         //! Enables CRC mechanism at runtime.
         bool 						_crc_enabled;
         //! Table storing byte CRCs for Intel instruction.
         unsigned int 				_mul_table1_336[256];
         //! Table storing byte CRCs for Intel instruction.
         unsigned int 				_mul_table1_672[256];
         //! Table storing byte CRCs when calculating CRC in software.
         unsigned int				_crcTable[256];
         //! Flag when TRUE showing the Intel instruction is available to calculate CRC. Otherwise CRCs are calculated in software.
         bool 						_crcParam;
         //! Struct for three copies of CRCs.
         typedef struct{
                unsigned int crc1;
                unsigned int crc2;
                unsigned int crc3;
          }crcStruct;
         //! Hashmap to store the computed CRCs.
         HashMap<uint64_t, crcStruct> _hashmap;



      public:
         /*! \brief Obtain the CopyData's CRC-32 by majority vote among the copies.
          */
         unsigned int getCRC32(uint64_t address);

          /*  Set the CopyData's CRC-32 copies.
	   *  @param address: the address of the data for which the CRC will be set
	   *  @param int: the CRC to be set
           */
          void setCRC32(uint64_t address, unsigned int);

         /*!
          * \brief Calculates the CRC-32 of the given buffer using Intel instruction.
          */
         unsigned int compute_Crc32(unsigned int initval, void *buf, size_t bufLen );
         /*!
          * \brief Sub-function for the CRC-32 calculation.
          */
         unsigned int subcompute_Crc32(long long unsigned int  initval, void *buffer);
         /*!
          * \brief Calculates the CRC-32 of the given buffer in software.
          */
         unsigned int compute_Crc32_Software(unsigned int initval, void *buf, size_t bufLen);
         /*!
          * \brief Starts the CRC-32 calculation.
          *
          */
         void startComputeCRC(WD &wd);
         /*!
          * \brief Checks the existence of SDCs vi CRC-32.
          *
          */
         bool checkSDCviaCRC32(WD &wd);
         /*!
          * \brief Restores the WD wd if some SDCs are detected.
          *
          */
         void restore(WD &wd);

}
   extern System sys;

} // namespace nanos

#endif

