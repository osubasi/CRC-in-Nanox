/*************************************************************************************/
/*      Copyright 2015 Barcelona Supercomputing Center                               */
/*                                                                                   */
/*      This file is part of the NANOS++ library.                                    */
/*                                                                                   */
/*      NANOS++ is free software: you can redistribute it and/or modify              */
/*      it under the terms of the GNU Lesser General Public License as published by  */
/*      the Free Software Foundation, either version 3 of the License, or            */
/*      (at your option) any later version.                                          */
/*                                                                                   */
/*      NANOS++ is distributed in the hope that it will be useful,                   */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of               */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                */
/*      GNU Lesser General Public License for more details.                          */
/*                                                                                   */
/*      You should have received a copy of the GNU Lesser General Public License     */
/*      along with NANOS++.  If not, see <http://www.gnu.org/licenses/>.             */
/*************************************************************************************/


#ifdef NANOS_RESILIENCY_ENABLED
#include "backupmanager.hpp"
#include "exception/signaltranslator.hpp"
#include "exception/operationfailure.hpp"
#include <cpuid.h>
#include "hashmap.hpp"
#include <nmmintrin.h>
#endif

#include "system.hpp"
#include "config.hpp"
#include "plugin.hpp"
#include "schedule.hpp"
#include "barrier.hpp"
#include "nanos-int.h"
#include "copydata.hpp"
#include "os.hpp"
#include "basethread.hpp"
#include "malign.hpp"
#include "processingelement.hpp"
#include "basethread.hpp"
#include "allocator.hpp"
#include "debug.hpp"

#include "smpthread.hpp"
#include "regiondict.hpp"
#include "smpprocessor.hpp"
#include "location.hpp"
#include "router.hpp"
#include "addressspace.hpp"
#include "globalregt.hpp"

#ifdef SPU_DEV
#include "spuprocessor.hpp"
#endif

#ifdef CLUSTER_DEV
#include "clusternode_decl.hpp"
#include "clusterthread_decl.hpp"
#endif
#include "clustermpiplugin_decl.hpp"

#include "addressspace.hpp"

#ifdef NANOS_INSTRUMENTATION_ENABLED
#   include "mainfunction.hpp"
#endif

#include <mutex>
#include <set>

#include <climits>
#include <cstring>


using namespace nanos;

System nanos::sys;
/*! System Class */
class System;
// default system values go here
System::System () :
      _atomicWDSeed( 1 ), _threadIdSeed( 0 ), _peIdSeed( 0 ), _SMP("SMP"),
      /*jb _numPEs( INT_MAX ), _numThreads( 0 ),*/ _deviceStackSize( 0 ), _profile( false ),
      _instrument( false ), _verboseMode( false ), _summary( false ), _executionMode( DEDICATED ), _initialMode( POOL ),
      _untieMaster( true ), _delayedStart( false ), _synchronizedStart( true ), _alreadyFinished( false ),
      _predecessorLists( false ), _throttlePolicy ( NULL ),
      _schedStats(), _schedConf(), _defSchedule( "bf" ), _defThrottlePolicy( "hysteresis" ), 
      _defBarr( "centralized" ), _defInstr ( "empty_trace" ), _defDepsManager( "plain" ), _defArch( "smp" ),
      _initializedThreads ( 0 ), /*_targetThreads ( 0 ),*/ _pausedThreads( 0 ),
      _pausedThreadsCond(), _unpausedThreadsCond(),
      _net(), _usingCluster( false ), _usingClusterMPI( false ), _clusterMPIPlugin( NULL ), _usingNode2Node( true ), _usingPacking( true ), _conduit( "udp" ),
      _instrumentation ( NULL ), _defSchedulePolicy( NULL ), _dependenciesManager( NULL ),
      _pmInterface( NULL ), _masterGpuThd( NULL ), _separateMemorySpacesCount(1), _separateAddressSpaces(1024), _hostMemory( ext::getSMPDevice() ),
      _regionCachePolicy( RegionCache::WRITE_BACK ), _regionCachePolicyStr(""), _regionCacheSlabSize(0), _clusterNodes(), _numaNodes(),
      _activeMemorySpaces(), _acceleratorCount(0), _numaNodeMap(), _threadManagerConf(), _threadManager( NULL )
#ifdef GPU_DEV
      , _pinnedMemoryCUDA( NEW CUDAPinnedMemoryManager() )
#endif
#ifdef NANOS_INSTRUMENTATION_ENABLED
      , _mainFunctionEvent( NULL )
      , _enableEvents(), _disableEvents(), _instrumentDefault("default"), _enableCpuidEvent( false )
#endif
      , _lockPoolSize(37), _lockPool( NULL ), _mainTeam (NULL), _simulator(false)
#ifdef NANOS_RESILIENCY_ENABLED
      , _injectionPolicy( "none" )
      , _resiliency_disabled(false)
      , _task_max_trials(1)
      , _backup_pool_size(sysconf(_SC_PAGESIZE ) * sysconf(_SC_PHYS_PAGES) / 20)
      , _crcParam()
      , _hashmap()
#endif
      , _affinityFailureCount( 0 )
      , _createLocalTasks( false )
      , _verboseDevOps( false )
      , _verboseCopies( false )
      , _splitOutputForThreads( false )
      , _userDefinedNUMANode( -1 )
      , _router()
      , _hwloc()
      , _immediateSuccessorDisabled( false )
      , _predecessorCopyInfoDisabled( false )
      , _invalControl( false )
      , _cgAlloc( false )
      , _inIdle( false )
	  , _lazyPrivatizationEnabled (false)
	  , _watchAddr(nullptr)
{
   verbose( "NANOS++ initializing... start" );

   // OS::init must be called here and not in System::start() as it can be too late
   // to locate the program arguments at that point
   OS::init();
   config();

   _lockPool = NEW Lock[_lockPoolSize];

   if ( !_delayedStart ) {
      //std::cerr << "NX_ARGS is:" << (char *)(OS::getEnvironmentVariable( "NX_ARGS" ) != NULL ? OS::getEnvironmentVariable( "NX_ARGS" ) : "NO NX_ARGS: GG!") << std::endl;
      start();
   }
   verbose( "NANOS++ initializing... end" );
}

/*! \brief Defines the CRC-32 mechanism's environment flag.
*/
void System::config ()
{
   Config cfg;

   const OS::InitList & externalInits = OS::getInitializationFunctions();
   std::for_each(externalInits.begin(),externalInits.end(), ExecInit());
   
   //! Declare all configuration core's flags
   verbose( "Preparing library configuration" );

   cfg.setOptionsSection( "Core", "Core options of the core of Nanos++ runtime" );

   cfg.registerConfigOption( "stack-size", NEW Config::SizeVar( _deviceStackSize ), "Default stack size (all devices)" );
   cfg.registerArgOption( "stack-size", "stack-size" );
   cfg.registerEnvOption( "stack-size", "NX_STACK_SIZE" );

   cfg.registerConfigOption( "verbose", NEW Config::FlagOption( _verboseMode ),
                             "Activates verbose mode" );
   cfg.registerArgOption( "verbose", "verbose" );

   cfg.registerConfigOption( "summary", NEW Config::FlagOption( _summary ),
                             "Activates summary mode" );
   cfg.registerArgOption( "summary", "summary" );

//! \bug implement execution modes (#146) */
#if 0
   cfg::MapVar<ExecutionMode> map( _executionMode );
   map.addOption( "dedicated", DEDICATED).addOption( "shared", SHARED );
   cfg.registerConfigOption ( "exec_mode", &map, "Execution mode" );
   cfg.registerArgOption ( "exec_mode", "mode" );
#endif

   registerPluginOption( "schedule", "sched", _defSchedule,
                         "Defines the scheduling policy", cfg );
   cfg.registerArgOption( "schedule", "schedule" );
   cfg.registerEnvOption( "schedule", "NX_SCHEDULE" );

   registerPluginOption( "throttle", "throttle", _defThrottlePolicy,
                         "Defines the throttle policy", cfg );
   cfg.registerArgOption( "throttle", "throttle" );
   cfg.registerEnvOption( "throttle", "NX_THROTTLE" );

   cfg.registerConfigOption( "barrier", NEW Config::StringVar ( _defBarr ),
                             "Defines barrier algorithm" );
   cfg.registerArgOption( "barrier", "barrier" );
   cfg.registerEnvOption( "barrier", "NX_BARRIER" );

   registerPluginOption( "instrumentation", "instrumentation", _defInstr,
                         "Defines instrumentation format", cfg );
   cfg.registerArgOption( "instrumentation", "instrumentation" );
   cfg.registerEnvOption( "instrumentation", "NX_INSTRUMENTATION" );

   cfg.registerConfigOption( "no-sync-start", NEW Config::FlagOption( _synchronizedStart, false),
                             "Disables synchronized start" );
   cfg.registerArgOption( "no-sync-start", "disable-synchronized-start" );

   cfg.registerConfigOption( "architecture", NEW Config::StringVar ( _defArch ),
                             "Defines the architecture to use (smp by default)" );
   cfg.registerArgOption( "architecture", "architecture" );
   cfg.registerEnvOption( "architecture", "NX_ARCHITECTURE" );

   registerPluginOption( "deps", "deps", _defDepsManager,
                         "Defines the dependencies plugin", cfg );
   cfg.registerArgOption( "deps", "deps" );
   cfg.registerEnvOption( "deps", "NX_DEPS" );
   

#ifdef NANOS_INSTRUMENTATION_ENABLED
   cfg.registerConfigOption( "instrument-default", NEW Config::StringVar ( _instrumentDefault ),
                             "Set instrumentation event list default (none, all)" );
   cfg.registerArgOption( "instrument-default", "instrument-default" );

   cfg.registerConfigOption( "instrument-enable", NEW Config::StringVarList ( _enableEvents ),
                             "Add events to instrumentation event list" );
   cfg.registerArgOption( "instrument-enable", "instrument-enable" );

   cfg.registerConfigOption( "instrument-disable", NEW Config::StringVarList ( _disableEvents ),
                             "Remove events to instrumentation event list" );
   cfg.registerArgOption( "instrument-disable", "instrument-disable" );

   cfg.registerConfigOption( "instrument-cpuid", NEW Config::FlagOption ( _enableCpuidEvent ),
                             "Add cpuid event when binding is disabled (expensive)" );
   cfg.registerArgOption( "instrument-cpuid", "instrument-cpuid" );
#endif

   /* Cluster: load the cluster support */
   cfg.registerConfigOption ( "enable-cluster", NEW Config::FlagOption ( _usingCluster, true ), "Enables the usage of Nanos++ Cluster" );
   cfg.registerArgOption ( "enable-cluster", "cluster" );
   //cfg.registerEnvOption ( "enable-cluster", "NX_ENABLE_CLUSTER" );
   cfg.registerConfigOption ( "enable-cluster-mpi", NEW Config::FlagOption ( _usingClusterMPI, true ), "Enables the usage of Nanos++ Cluster with MPI applications" );
   cfg.registerArgOption ( "enable-cluster-mpi", "cluster-mpi" );

   cfg.registerConfigOption ( "no-node2node", NEW Config::FlagOption ( _usingNode2Node, false ), "Disables the usage of Slave-to-Slave transfers" );
   cfg.registerArgOption ( "no-node2node", "disable-node2node" );
   cfg.registerConfigOption ( "no-pack", NEW Config::FlagOption ( _usingPacking, false ), "Disables the usage of packing and unpacking of strided transfers" );
   cfg.registerArgOption ( "no-pack", "disable-packed-copies" );

   /* Cluster: select wich module to load mpi or udp */
   cfg.registerConfigOption ( "conduit", NEW Config::StringVar ( _conduit ), "Selects which GasNet conduit will be used" );
   cfg.registerArgOption ( "conduit", "cluster-network" );
   cfg.registerEnvOption ( "conduit", "NX_CLUSTER_NETWORK" );

#if 0 /* _defDeviceName and _defDevice seem unused */
   cfg.registerConfigOption ( "device-priority", NEW Config::StringVar ( _defDeviceName ), "Defines the default device to use");
   cfg.registerArgOption ( "device-priority", "--use-device");
   cfg.registerEnvOption ( "device-priority", "NX_USE_DEVICE");
#endif
   cfg.registerConfigOption( "simulator", NEW Config::FlagOption ( _simulator ),
                             "Nanos++ will be executed by a simulator (disabled as default)" );
   cfg.registerArgOption( "simulator", "simulator" );

#ifdef NANOS_RESILIENCY_ENABLED
   cfg.registerConfigOption("disable_resiliency",
         NEW Config::FlagOption(_resiliency_disabled, true),
         "Disables all resiliency mechanisms. ");
   cfg.registerArgOption("disable_resiliency", "disable-resiliency");
   cfg.registerEnvOption("disable_resiliency", "NX_DISABLE_RESILIENCY");

   cfg.registerConfigOption("task_retrials",
         NEW Config::UintVar(_task_max_trials),
         "Defines the number of times a restartable task can be re-executed (default: 1). ");
   cfg.registerArgOption("task_retrials", "task-retrials");
   cfg.registerEnvOption("task_retrials", "NX_TASK_RETRIALS");

   cfg.registerConfigOption("backup_pool_size",
         NEW Config::SizeVar(_backup_pool_size),
         "Sets the memory pool maximum size (dedicated to store task backups) in bytes. ");
   cfg.registerArgOption("backup_pool_size", "backup-pool-size");
   cfg.registerEnvOption("backup_pool_size", "NX_BACKUP_POOL_SIZE");

   registerPluginOption("error_injection", "error-injection", _injectionPolicy,
         "Selects error injection policy. Used for resiliency evaluation.", cfg);
   cfg.registerArgOption("error_injection", "error-injection");
   cfg.registerEnvOption("error_injection", "NX_ERROR_INJECTION");

   cfg.registerConfigOption("enable_crc", NEW Config::FlagOption(_crc_enabled, true), "Enables CRC protection. ");
   cfg.registerArgOption("enable_crc", "enable-crc");
   cfg.registerEnvOption("enable_crc", "NX_ENABLE_CRC");
#endif

   cfg.registerConfigOption ( "verbose-devops", NEW Config::FlagOption ( _verboseDevOps, true ), "Verbose cache ops" );
   cfg.registerArgOption ( "verbose-devops", "verbose-devops" );
   cfg.registerConfigOption ( "verbose-copies", NEW Config::FlagOption ( _verboseCopies, true ), "Verbose data copies" );
   cfg.registerArgOption ( "verbose-copies", "verbose-copies" );

   cfg.registerConfigOption ( "thd-output", NEW Config::FlagOption ( _splitOutputForThreads, true ), "Create separate files for each thread" );
   cfg.registerArgOption ( "thd-output", "thd-output" );

   cfg.registerConfigOption ( "regioncache-policy", NEW Config::StringVar ( _regionCachePolicyStr ), "Region cache policy, accepted values are : nocache, writethrough, writeback, fpga. Default is writeback." );
   cfg.registerArgOption ( "regioncache-policy", "cache-policy" );
   cfg.registerEnvOption ( "regioncache-policy", "NX_CACHE_POLICY" );

   cfg.registerConfigOption ( "regioncache-slab-size", NEW Config::SizeVar ( _regionCacheSlabSize ), "Region slab size." );
   cfg.registerArgOption ( "regioncache-slab-size", "cache-slab-size" );
   cfg.registerEnvOption ( "regioncache-slab-size", "NX_CACHE_SLAB_SIZE" );

   cfg.registerConfigOption( "disable-immediate-succ", NEW Config::FlagOption( _immediateSuccessorDisabled ), "Disables the usage of getImmediateSuccessor" );
   cfg.registerArgOption( "disable-immediate-succ", "disable-immediate-successor" );

   cfg.registerConfigOption( "disable-predecessor-info", NEW Config::FlagOption( _predecessorCopyInfoDisabled ),
                             "Disables sending the copy_data info to successor WDs." );
   cfg.registerArgOption( "disable-predecessor-info", "disable-predecessor-info" );
   cfg.registerConfigOption( "inval-control", NEW Config::FlagOption( _invalControl ),
                             "Inval control." );
   cfg.registerArgOption( "inval-control", "inval-control" );

   cfg.registerConfigOption( "cg-alloc", NEW Config::FlagOption( _cgAlloc ),
                             "CG alloc." );
   cfg.registerArgOption( "cg-alloc", "cg-alloc" );

   cfg.registerConfigOption ( "enable-lazy-privatization", NEW Config::BoolVar ( _lazyPrivatizationEnabled ),
		   "Enable lazy reduction privatization" );
   cfg.registerArgOption ( "enable-lazy-privatization", "enable-lazy-privatization" );

   _schedConf.config( cfg );

   _hwloc.config( cfg );
   _threadManagerConf.config( cfg );

   verbose ( "Reading Configuration" );

   cfg.init();
   
   // Now read compiler-supplied flags
   // Open the own executable
   void * myself = dlopen(NULL, RTLD_LAZY | RTLD_GLOBAL);

   // Check if the compiler marked myself as requiring priorities (#1041)
   _compilerSuppliedFlags.prioritiesNeeded = dlsym(myself, "nanos_need_priorities_") != NULL;
   
   // Close handle to myself
   dlclose( myself );
}
/*! \brief Initializes the CRC mechanims data structures.
 */
void System::start ()
{
   _hwloc.loadHwloc();
   
   // Modules can be loaded now
   loadArchitectures();
   loadModules();

   verbose( "Stating PM interface.");
   Config cfg;
   void (*f)(void *) = nanos::PMInterfaceType::set_interface;
   f(NULL);
   _pmInterface->config( cfg );
   cfg.init();
   _pmInterface->start();

   // Instrumentation startup
   NANOS_INSTRUMENT ( sys.getInstrumentation()->filterEvents( _instrumentDefault, _enableEvents, _disableEvents ) );
   NANOS_INSTRUMENT ( sys.getInstrumentation()->initialize() );

   verbose ( "Starting runtime" );

   if ( _regionCachePolicyStr.compare("") != 0 ) {
      //value is set
      if ( _regionCachePolicyStr.compare("nocache") == 0 ) {
         _regionCachePolicy = RegionCache::NO_CACHE;
      } else if ( _regionCachePolicyStr.compare("writethrough") == 0 ) {
         _regionCachePolicy = RegionCache::WRITE_THROUGH;
      } else if ( _regionCachePolicyStr.compare("writeback") == 0 ) {
         _regionCachePolicy = RegionCache::WRITE_BACK;
      } else if ( _regionCachePolicyStr.compare("fpga") == 0 ) {
         _regionCachePolicy = RegionCache::FPGA;
      } else {
         warning( "Invalid option for region cache policy '", _regionCachePolicyStr,
                   "', using default value."
                 );
      }
   }

   //don't allow untiedMaster in cluster, otherwise Nanos finalization crashes
   _smpPlugin->associateThisThread( usingCluster() ? false : getUntieMaster() );

   //Setup MainWD
   WD &mainWD = *myThread->getCurrentWD();
   mainWD._mcontrol.setMainWD();

   if ( _pmInterface->getInternalDataSize() > 0 ) {
      char *data = NEW char[_pmInterface->getInternalDataSize()];
      _pmInterface->initInternalData( data );
      mainWD.setInternalData( data );
   }
   _pmInterface->setupWD( mainWD );

   if ( _defSchedulePolicy->getWDDataSize() > 0 ) {
      char *data = NEW char[ _defSchedulePolicy->getWDDataSize() ];
      _defSchedulePolicy->initWDData( data );
      mainWD.setSchedulerData( reinterpret_cast<ScheduleWDData*>( data ), /* ownedByWD */ true );
   }

   /* Renaming currend thread as Master */
   myThread->rename("Master");
   NANOS_INSTRUMENT ( sys.getInstrumentation()->raiseOpenStateEvent (NANOS_STARTUP) );

   for ( ArchitecturePlugins::const_iterator it = _archs.begin();
        it != _archs.end(); ++it )
   {
      verbose("addPEs for arch: ", (*it)->getName());
      (*it)->addPEs( _pes );
      (*it)->addDevices( _devices );
   }
   
   for ( ArchitecturePlugins::const_iterator it = _archs.begin();
        it != _archs.end(); ++it )
   {
      (*it)->startSupportThreads();
   }   
   
   for ( ArchitecturePlugins::const_iterator it = _archs.begin();
        it != _archs.end(); ++it )
   {
      (*it)->startWorkerThreads( _workers );
   }   

   for ( PEList::iterator it = _pes.begin(); it != _pes.end(); it++ ) {
      if ( it->second->isActive() ) {
         _clusterNodes.insert( it->second->getClusterNode() );
         // If this PE is in a NUMA node and has workers
         if ( it->second->isInNumaNode() && ( it->second->getNumThreads() > 0  ) ) {
            // Add the node of this PE to the set of used NUMA nodes
            unsigned node = it->second->getNumaNode() ;
            _numaNodes.insert( node );
         }
         _activeMemorySpaces.insert( it->second->getMemorySpaceId() );
      }
   }
   
   // gmiranda: was completeNUMAInfo() We must do this after the
   // previous loop since we need the size of _numaNodes
   
   unsigned availNUMANodes = 0;
   // #994: this should be the number of NUMA objects in hwloc, but if we don't
   // want to query, this max should be enough
   unsigned maxNUMANode = _numaNodes.empty() ? 1 : *std::max_element( _numaNodes.begin(), _numaNodes.end() );
   // Create the NUMA node translation table. Do this before creating the team,
   // as the schedulers might need the information.
   _numaNodeMap.resize( maxNUMANode + 1, INT_MIN );
   
   for ( std::set<unsigned int>::const_iterator it = _numaNodes.begin();
        it != _numaNodes.end(); ++it )
   {
      unsigned node = *it;
      // If that node has not been translated, yet
      if ( _numaNodeMap[ node ] == INT_MIN )
      {
         verbose( "[NUMA] Mapping from physical node ", node,
                   " to user node ", availNUMANodes
                 );
         _numaNodeMap[ node ] = availNUMANodes;
         // Increase the number of available NUMA nodes
         ++availNUMANodes;
      }
      // Otherwise, do nothing
   }
   verbose( "[NUMA] ", availNUMANodes, " NUMA node(s) available for the user." );

   // For each plugin, notify it's the way to reserve PEs if they are required
   //for ( ArchitecturePlugins::const_iterator it = _archs.begin();
   //     it != _archs.end(); ++it )
   //{
   //   (*it)->createBindingList();
   //}

#ifdef NANOS_RESILIENCY_ENABLED   // compile time disable
   if(sys.isResiliencyEnabled()){// runtime disable
      // Insert a new separate memory address space to store input backups
      BackupManager* mgr = new BackupManager("BackupMgr", _backup_pool_size);

      memory_space_id_t backup_id = addSeparateMemoryAddressSpace( *mgr, true /*allocWide*/, 0 /* slabSize*/ );
      _backupMemory = &getSeparateMemory( backup_id );
   }
#endif   

   _targetThreads = _smpPlugin->getNumThreads();

   // Set up internal data for each worker
   for ( ThreadList::const_iterator it = _workers.begin(); it != _workers.end(); it++ ) {

      WD & threadWD = it->second->getThreadWD();
      if ( _pmInterface->getInternalDataSize() > 0 ) {
         char *data = NEW char[_pmInterface->getInternalDataSize()];
         _pmInterface->initInternalData( data );
         threadWD.setInternalData( data );
      }
      _pmInterface->setupWD( threadWD );

      int schedDataSize = _defSchedulePolicy->getWDDataSize();
      if ( schedDataSize  > 0 ) {
         ScheduleWDData *schedData = reinterpret_cast<ScheduleWDData*>( NEW char[schedDataSize] );
         _defSchedulePolicy->initWDData( schedData );
         threadWD.setSchedulerData( schedData, true );
      }

   }

#if 0 /* _defDeviceName and _defDevice seem unused */
   if ( !_defDeviceName.empty() ) 
   {
       PEList::iterator it;
       for ( it = _pes.begin() ; it != _pes.end(); it++ )
       {
           PE *pe = it->second;
           if ( pe->getDeviceType()->getName() != NULL)
              if ( _defDeviceName == pe->getDeviceType()->getName()  )
                 _defDevice = pe->getDeviceType();
       }
   }
#endif

#ifdef NANOS_RESILIENCY_ENABLED
   error::SignalTranslator<error::OperationFailure> signalToExceptionTranslator;
#endif

   if ( getSynchronizedStart() ) threadReady();

   switch ( getInitialMode() )
   {
      case POOL:
         verbose("Pool model enabled (OmpSs)");
         _mainTeam = createTeam( _workers.size(), /*constraints*/ NULL, /*reuse*/ true, /*enter*/ true, /*parallel*/ false );
         break;
      case ONE_THREAD:
         verbose("One-thread model enabled (OpenMP)");
         _mainTeam = createTeam( 1, /*constraints*/ NULL, /*reuse*/ true, /*enter*/ true, /*parallel*/ true );
         break;
      default:
         fatal("Unknown initial mode!");
         break;
   }

   _router.initialize();
   _net.setParentWD( &mainWD );
   if ( usingCluster() )
   {
      _net.nodeBarrier();
   }

   NANOS_INSTRUMENT ( static InstrumentationDictionary *ID = sys.getInstrumentation()->getInstrumentationDictionary(); )
   NANOS_INSTRUMENT ( static nanos_event_key_t num_threads_key = ID->getEventKey("set-num-threads"); )
   NANOS_INSTRUMENT ( nanos_event_value_t team_size =  (nanos_event_value_t) myThread->getTeam()->size(); )
   NANOS_INSTRUMENT ( sys.getInstrumentation()->raisePointEvents(1, &num_threads_key, &team_size); )
   
   // Paused threads: set the condition checker 
   _pausedThreadsCond.setConditionChecker( EqualConditionChecker<unsigned int >( &_pausedThreads.override(), _workers.size() ) );
   _unpausedThreadsCond.setConditionChecker( EqualConditionChecker<unsigned int >( &_pausedThreads.override(), 0 ) );

   // All initialization is ready, call postInit hooks
   const OS::InitList & externalInits = OS::getPostInitializationFunctions();
   std::for_each(externalInits.begin(),externalInits.end(), ExecInit());

   NANOS_INSTRUMENT ( sys.getInstrumentation()->raiseCloseStateEvent() );
   NANOS_INSTRUMENT ( sys.getInstrumentation()->raiseOpenStateEvent (NANOS_RUNNING) );

   // List unrecognised arguments
   std::string unrecog = Config::getOrphanOptions();
   if ( !unrecog.empty() )
      warning( "Unrecognised arguments: ", unrecog );
   Config::deleteOrphanOptions();
      
   if ( _summary ) {
      environmentSummary();

#ifdef HAVE_CXX11
		// TODO: move this to the new exception design directory
      // If the summary is enabled, print the final execution summary
      // even if the application is terminated by an error.
      std::set_terminate( [](){
         static std::once_flag called_once;
         call_once( called_once, []() {
            sys.executionSummary();
#ifdef __GNUG__
            // Call verbose terminate handler: prints exception information
            // This is a gnu extension
            __gnu_cxx::__verbose_terminate_handler();
#else
            message( "An error was reported and this program will finish." );
            std::abort();
#endif
         });
      });
#endif
   }

   // Thread Manager initialization is delayed until a safe point
   _threadManager->init();

#ifdef NANOS_RESILIENCY_ENABLED //OMER::ENCODING
   if(sys._crc_enabled){
	   unsigned int eax = 0, ebx = 0, ecx = 0, edx = 0;

	   __get_cpuid(1, &eax, &ebx, &ecx, &edx);

	   if (ecx & bit_SSE4_2){
		   // i have the instruction
		   _crcParam = true;
		//#define CRC_SUPPORTED 
		   //std::cerr << "Intel CRC Exists "<<std::endl;
		   unsigned int temp[256] = {
				0x00000000,0x8f158014,0x1bc776d9,0x94d2f6cd,
				0x378eedb2,0xb89b6da6,0x2c499b6b,0xa35c1b7f,
				0x6f1ddb64,0xe0085b70,0x74daadbd,0xfbcf2da9,
				0x589336d6,0xd786b6c2,0x4354400f,0xcc41c01b,
				0xde3bb6c8,0x512e36dc,0xc5fcc011,0x4ae94005,
				0xe9b55b7a,0x66a0db6e,0xf2722da3,0x7d67adb7,
				0xb1266dac,0x3e33edb8,0xaae11b75,0x25f49b61,
				0x86a8801e,0x09bd000a,0x9d6ff6c7,0x127a76d3,
				0xb99b1b61,0x368e9b75,0xa25c6db8,0x2d49edac,
				0x8e15f6d3,0x010076c7,0x95d2800a,0x1ac7001e,
				0xd686c005,0x59934011,0xcd41b6dc,0x425436c8,
				0xe1082db7,0x6e1dada3,0xfacf5b6e,0x75dadb7a,
				0x67a0ada9,0xe8b52dbd,0x7c67db70,0xf3725b64,
				0x502e401b,0xdf3bc00f,0x4be936c2,0xc4fcb6d6,
				0x08bd76cd,0x87a8f6d9,0x137a0014,0x9c6f8000,
				0x3f339b7f,0xb0261b6b,0x24f4eda6,0xabe16db2,
				0x76da4033,0xf9cfc027,0x6d1d36ea,0xe208b6fe,
				0x4154ad81,0xce412d95,0x5a93db58,0xd5865b4c,
				0x19c79b57,0x96d21b43,0x0200ed8e,0x8d156d9a,
				0x2e4976e5,0xa15cf6f1,0x358e003c,0xba9b8028,
				0xa8e1f6fb,0x27f476ef,0xb3268022,0x3c330036,
				0x9f6f1b49,0x107a9b5d,0x84a86d90,0x0bbded84,
				0xc7fc2d9f,0x48e9ad8b,0xdc3b5b46,0x532edb52,
				0xf072c02d,0x7f674039,0xebb5b6f4,0x64a036e0,
				0xcf415b52,0x4054db46,0xd4862d8b,0x5b93ad9f,
				0xf8cfb6e0,0x77da36f4,0xe308c039,0x6c1d402d,
				0xa05c8036,0x2f490022,0xbb9bf6ef,0x348e76fb,
				0x97d26d84,0x18c7ed90,0x8c151b5d,0x03009b49,
				0x117aed9a,0x9e6f6d8e,0x0abd9b43,0x85a81b57,
				0x26f40028,0xa9e1803c,0x3d3376f1,0xb226f6e5,
				0x7e6736fe,0xf172b6ea,0x65a04027,0xeab5c033,
				0x49e9db4c,0xc6fc5b58,0x522ead95,0xdd3b2d81,
				0xedb48066,0x62a10072,0xf673f6bf,0x796676ab,
				0xda3a6dd4,0x552fedc0,0xc1fd1b0d,0x4ee89b19,
				0x82a95b02,0x0dbcdb16,0x996e2ddb,0x167badcf,
				0xb527b6b0,0x3a3236a4,0xaee0c069,0x21f5407d,
				0x338f36ae,0xbc9ab6ba,0x28484077,0xa75dc063,
				0x0401db1c,0x8b145b08,0x1fc6adc5,0x90d32dd1,
				0x5c92edca,0xd3876dde,0x47559b13,0xc8401b07,
				0x6b1c0078,0xe409806c,0x70db76a1,0xffcef6b5,
				0x542f9b07,0xdb3a1b13,0x4fe8edde,0xc0fd6dca,
				0x63a176b5,0xecb4f6a1,0x7866006c,0xf7738078,
				0x3b324063,0xb427c077,0x20f536ba,0xafe0b6ae,
				0x0cbcadd1,0x83a92dc5,0x177bdb08,0x986e5b1c,
				0x8a142dcf,0x0501addb,0x91d35b16,0x1ec6db02,
				0xbd9ac07d,0x328f4069,0xa65db6a4,0x294836b0,
				0xe509f6ab,0x6a1c76bf,0xfece8072,0x71db0066,
				0xd2871b19,0x5d929b0d,0xc9406dc0,0x4655edd4,
				0x9b6ec055,0x147b4041,0x80a9b68c,0x0fbc3698,
				0xace02de7,0x23f5adf3,0xb7275b3e,0x3832db2a,
				0xf4731b31,0x7b669b25,0xefb46de8,0x60a1edfc,
				0xc3fdf683,0x4ce87697,0xd83a805a,0x572f004e,
				0x4555769d,0xca40f689,0x5e920044,0xd1878050,
				0x72db9b2f,0xfdce1b3b,0x691cedf6,0xe6096de2,
				0x2a48adf9,0xa55d2ded,0x318fdb20,0xbe9a5b34,
				0x1dc6404b,0x92d3c05f,0x06013692,0x8914b686,
				0x22f5db34,0xade05b20,0x3932aded,0xb6272df9,
				0x157b3686,0x9a6eb692,0x0ebc405f,0x81a9c04b,
				0x4de80050,0xc2fd8044,0x562f7689,0xd93af69d,
				0x7a66ede2,0xf5736df6,0x61a19b3b,0xeeb41b2f,
				0xfcce6dfc,0x73dbede8,0xe7091b25,0x681c9b31,
				0xcb40804e,0x4455005a,0xd087f697,0x5f927683,
				0x93d3b698,0x1cc6368c,0x8814c041,0x07014055,
				0xa45d5b2a,0x2b48db3e,0xbf9a2df3,0x308fade7

		   };

		   unsigned int temp2[256] = {
				0x00000000,0xe417f38a,0xcdc391e5,0x29d4626f,
				0x9e6b553b,0x7a7ca6b1,0x53a8c4de,0xb7bf3754,
				0x393adc87,0xdd2d2f0d,0xf4f94d62,0x10eebee8,
				0xa75189bc,0x43467a36,0x6a921859,0x8e85ebd3,
				0x7275b90e,0x96624a84,0xbfb628eb,0x5ba1db61,
				0xec1eec35,0x08091fbf,0x21dd7dd0,0xc5ca8e5a,
				0x4b4f6589,0xaf589603,0x868cf46c,0x629b07e6,
				0xd52430b2,0x3133c338,0x18e7a157,0xfcf052dd,
				0xe4eb721c,0x00fc8196,0x2928e3f9,0xcd3f1073,
				0x7a802727,0x9e97d4ad,0xb743b6c2,0x53544548,
				0xddd1ae9b,0x39c65d11,0x10123f7e,0xf405ccf4,
				0x43bafba0,0xa7ad082a,0x8e796a45,0x6a6e99cf,
				0x969ecb12,0x72893898,0x5b5d5af7,0xbf4aa97d,
				0x08f59e29,0xece26da3,0xc5360fcc,0x2121fc46,
				0xafa41795,0x4bb3e41f,0x62678670,0x867075fa,
				0x31cf42ae,0xd5d8b124,0xfc0cd34b,0x181b20c1,
				0xcc3a92c9,0x282d6143,0x01f9032c,0xe5eef0a6,
				0x5251c7f2,0xb6463478,0x9f925617,0x7b85a59d,
				0xf5004e4e,0x1117bdc4,0x38c3dfab,0xdcd42c21,
				0x6b6b1b75,0x8f7ce8ff,0xa6a88a90,0x42bf791a,
				0xbe4f2bc7,0x5a58d84d,0x738cba22,0x979b49a8,
				0x20247efc,0xc4338d76,0xede7ef19,0x09f01c93,
				0x8775f740,0x636204ca,0x4ab666a5,0xaea1952f,
				0x191ea27b,0xfd0951f1,0xd4dd339e,0x30cac014,
				0x28d1e0d5,0xccc6135f,0xe5127130,0x010582ba,
				0xb6bab5ee,0x52ad4664,0x7b79240b,0x9f6ed781,
				0x11eb3c52,0xf5fccfd8,0xdc28adb7,0x383f5e3d,
				0x8f806969,0x6b979ae3,0x4243f88c,0xa6540b06,
				0x5aa459db,0xbeb3aa51,0x9767c83e,0x73703bb4,
				0xc4cf0ce0,0x20d8ff6a,0x090c9d05,0xed1b6e8f,
				0x639e855c,0x878976d6,0xae5d14b9,0x4a4ae733,
				0xfdf5d067,0x19e223ed,0x30364182,0xd421b208,
				0x9d995363,0x798ea0e9,0x505ac286,0xb44d310c,
				0x03f20658,0xe7e5f5d2,0xce3197bd,0x2a266437,
				0xa4a38fe4,0x40b47c6e,0x69601e01,0x8d77ed8b,
				0x3ac8dadf,0xdedf2955,0xf70b4b3a,0x131cb8b0,
				0xefecea6d,0x0bfb19e7,0x222f7b88,0xc6388802,
				0x7187bf56,0x95904cdc,0xbc442eb3,0x5853dd39,
				0xd6d636ea,0x32c1c560,0x1b15a70f,0xff025485,
				0x48bd63d1,0xacaa905b,0x857ef234,0x616901be,
				0x7972217f,0x9d65d2f5,0xb4b1b09a,0x50a64310,
				0xe7197444,0x030e87ce,0x2adae5a1,0xcecd162b,
				0x4048fdf8,0xa45f0e72,0x8d8b6c1d,0x699c9f97,
				0xde23a8c3,0x3a345b49,0x13e03926,0xf7f7caac,
				0x0b079871,0xef106bfb,0xc6c40994,0x22d3fa1e,
				0x956ccd4a,0x717b3ec0,0x58af5caf,0xbcb8af25,
				0x323d44f6,0xd62ab77c,0xfffed513,0x1be92699,
				0xac5611cd,0x4841e247,0x61958028,0x858273a2,
				0x51a3c1aa,0xb5b43220,0x9c60504f,0x7877a3c5,
				0xcfc89491,0x2bdf671b,0x020b0574,0xe61cf6fe,
				0x68991d2d,0x8c8eeea7,0xa55a8cc8,0x414d7f42,
				0xf6f24816,0x12e5bb9c,0x3b31d9f3,0xdf262a79,
				0x23d678a4,0xc7c18b2e,0xee15e941,0x0a021acb,
				0xbdbd2d9f,0x59aade15,0x707ebc7a,0x94694ff0,
				0x1aeca423,0xfefb57a9,0xd72f35c6,0x3338c64c,
				0x8487f118,0x60900292,0x494460fd,0xad539377,
				0xb548b3b6,0x515f403c,0x788b2253,0x9c9cd1d9,
				0x2b23e68d,0xcf341507,0xe6e07768,0x02f784e2,
				0x8c726f31,0x68659cbb,0x41b1fed4,0xa5a60d5e,
				0x12193a0a,0xf60ec980,0xdfdaabef,0x3bcd5865,
				0xc73d0ab8,0x232af932,0x0afe9b5d,0xeee968d7,
				0x59565f83,0xbd41ac09,0x9495ce66,0x70823dec,
				0xfe07d63f,0x1a1025b5,0x33c447da,0xd7d3b450,
				0x606c8304,0x847b708e,0xadaf12e1,0x49b8e16b


		   };
		   for (int n = 0; n < 256; n++) {
			   _mul_table1_336[n] = temp[n];
			   _mul_table1_672[n] = temp2[n];
		   }

	   }
	   else{
		   // i dont have crc instruction
		   //std::cerr << "Intel CRC Does NOT Exist, Computing CRC in Software"<<std::endl;
			_crcParam = false;
			unsigned long c;
			int n, k;

			for (n = 0; n < 256; n++) {
				c = (unsigned long) n;
				for (k = 0; k < 8; k++) {
					if (c & 1)
						c = 0x04C11DB7 ^ (c >> 1); //0xBA0DC66B //0x04C11DB7
					else
						c = c >> 1;
				}
				_crcTable[n] = c;
			}
	   }
   }
#endif
}





/*! \brief Obtain the CopyData's CRC-32 by majority vote among the copies.
 *  \param address The address of the data whose CRC is to be got.
*  \return The CRC of the data with the given address.
*/
unsigned int System::getCRC32(uint64_t address)
{
	crcStruct *str = this->_hashmap.find(address);
	if(str==NULL)
	{
		str = (crcStruct*)malloc(sizeof(crcStruct *));
		str->crc1 = 0;
		str->crc2 = 0;
		str->crc3 = 0;
		bool inserted = false;
		_hashmap.insert(address, *str, inserted);
		return 0;
	}
	if(str->crc1==str->crc2){
		return str->crc1;
	}
	else if(str->crc1==str->crc3){
		return str->crc1;
	}
	else {
		return str->crc2;
	}

}
/*! 
*  \brief Set the CopyData's CRC-32 copies.
*  \param address The address of the data for which the CRC will be set.
*  \param inCrc32 The CRC to be set.
*/
void System::setCRC32(uint64_t address, unsigned int inCrc32 )
{
	crcStruct *str = this->_hashmap.find(address);
	if(str==NULL)
	{
		str = (crcStruct*)malloc(sizeof(crcStruct *));
		str->crc1 = inCrc32;
		str->crc2 = inCrc32;
		str->crc3 = inCrc32;
		bool inserted = false;
		_hashmap.insert(address, *str, inserted);
		return;
	}
	str->crc1 = inCrc32;
	str->crc2 = inCrc32;
	str->crc3 = inCrc32;
}
/*!
* \brief Calculates the CRC-32 of the given buffer using Intel instruction.
*  \param initval The initial CRC of the buffer.
*  \param buf The pointer to the data.
*  \param bufLen The length of the buffer (data) for which the CRC will be computed.
*  \return Computed CRC of the buffer (data).
*/
unsigned int System::compute_Crc32(unsigned int initval, void *buf, size_t bufLen)
{
	   unsigned int crc32 = initval;
	   unsigned char *byteBuf, *byteBuf2;
		size_t i;
		size_t res =  bufLen/1024;
		size_t remainder = bufLen%1024;

		byteBuf = (unsigned char*) buf;
		for (i=0; i < (res*1024); i+=1024) {
			crc32 = subcompute_Crc32(crc32, &byteBuf[i]);
		}
		byteBuf2 = (unsigned char*) &byteBuf[res*1024];
		for (i=0; i < remainder; i++) {
			crc32 = _mm_crc32_u8(crc32, byteBuf2[i]);
		}
		return crc32;
}
/*!
* \brief Sub-function for the CRC-32 calculation.
*  \param initval The initial CRC of the buffer.
*  \param buf The pointer to the data.
*  \return Computed CRC of the buffer (data).
*/
unsigned int System::subcompute_Crc32(long long unsigned int initval, void *buffer){
    uint64_t crc0, crc1, crc2, tmp; 
    uint64_t *p_buffer;
    uint64_t BLOCKSIZE = 336;
    uint64_t BLOCKSIZE8 = (BLOCKSIZE / 8);

    p_buffer = (uint64_t *)buffer;
    crc1 = crc2 = 0;

    // Do first 8 bytes here for better pipelining
    crc0 = _mm_crc32_u64((uint64_t)initval, p_buffer[0]);

    for(int i = 0; i < 42; i++){
      crc1 = _mm_crc32_u64(crc1, (uint64_t)(p_buffer[1 + 1*BLOCKSIZE8 + i]));
      crc2 = _mm_crc32_u64(crc2, (uint64_t)(p_buffer[1 + 2*BLOCKSIZE8 + i]));
      crc0 = _mm_crc32_u64(crc0, (uint64_t)(p_buffer[1 + 0*BLOCKSIZE8 + i]));
    }

    // merge in crc1
    tmp  = p_buffer[127];
    tmp ^= _mul_table1_336[crc1 & 0xFF];
    tmp ^= (_mul_table1_336[(crc1 >>  8) & 0xFF]) <<  8;
    tmp ^= (_mul_table1_336[(crc1 >> 16) & 0xFF]) << 16;
    tmp ^= (_mul_table1_336[(crc1 >> 24) & 0xFF]) << 24;

    // merge in crc0
    tmp ^= _mul_table1_672[crc0 & 0xFF];
    tmp ^= (_mul_table1_672[(crc0 >>  8) & 0xFF]) <<  8;
    tmp ^= (_mul_table1_672[(crc0 >> 16) & 0xFF]) << 16;
    tmp ^= (_mul_table1_672[(crc0 >> 24) & 0xFF]) << 24;

    return (unsigned int) _mm_crc32_u64(crc2, (uint64_t)tmp);
}
/*!
* \brief Calculates the CRC-32 of the given buffer in software.
*  \param initval The initial CRC of the buffer.
*  \param buf The pointer to the data.
*  \param bufLen The length of the buffer (data) for which the CRC will be computed.
*  \return Computed CRC of the buffer (data).
*/
unsigned int System::compute_Crc32_Software(unsigned int initval, void *buf, size_t bufLen)
{

    unsigned int crc32 = initval;
    unsigned char *byteBuf;
    size_t i;

    // accumulate crc32 for buffer
    //crc32 = inCrc32 ^ 0xFFFFFFFF;
    byteBuf = (unsigned char*) buf;
    for (i=0; i < bufLen; i++) {
    		crc32 = (crc32 >> 8) ^ _crcTable[ (crc32 ^ (byteBuf[i])) & 0xFF ];

    }
    return( crc32 ^ 0xFFFFFFFF );
}
/*!
* \brief Starts the CRC-32 calculation.
* \param wd The task whose output is to be processed.
*
*/
void System::startComputeCRC(WD &wd){
	if(_crcParam){
		for (unsigned int index = 0; index < wd.getNumCopies(); index++) {
			if (wd.getCopies()[index].isOutput()) {
				CopyData cd = wd.getCopies()[index];
				unsigned int inCrc32 = 0xFFFFFFFF;
				size_t len = cd.getSize();
				void *buffer = (void*) cd.getAddress();////
				uint64_t key = cd.getAddress().value();
				if(cd.getNumDimensions()>1){
					for (unsigned int i = 0; i < cd.getDimensions()[1].accessed_length; i += 1){
							uint64_t address = cd.getAddress().value() + cd.getDimensions()[0].accessed_length * i;
							buffer = (void *) address;
							len =  cd.getDimensions()[0].accessed_length;
							inCrc32 = sys.compute_Crc32(inCrc32, buffer, len);
					}
				}
				else{
					inCrc32 = sys.compute_Crc32(inCrc32, buffer, len);
				}
				setCRC32(key, inCrc32);
				//std::cerr << "Computed CRC "<<inCrc32<<std::endl;
			}
		}
	}
	else{
		for (unsigned int index = 0; index < wd.getNumCopies(); index++) {
			if (wd.getCopies()[index].isOutput()) {
				CopyData cd = wd.getCopies()[index];
				unsigned int inCrc32 = 0xFFFFFFFF;
				size_t len = cd.getSize();
				void *buffer = (void*) cd.getAddress();////
				uint64_t key = cd.getAddress().value();
				if(cd.getNumDimensions()>1){
					for (unsigned int i = 0; i < cd.getDimensions()[1].accessed_length; i += 1){
							uint64_t address = cd.getAddress().value() + cd.getDimensions()[0].accessed_length * i;
							buffer = (void *) address;
							len =  cd.getDimensions()[0].accessed_length;
							inCrc32 = sys.compute_Crc32_Software(inCrc32, buffer, len);
					}
				}
				else{
					inCrc32 = sys.compute_Crc32_Software(inCrc32, buffer, len);
				}
				setCRC32(key, inCrc32);
				//std::cerr << "Computed CRC "<<inCrc32<<std::endl;
			}
		}
	}

}
/*!
* \brief Checks the existence of SDCs vi CRC-32.
* \param wd The task whose inputs are to be checked againts silent errors.
* \return Whether any SDCs are detected or not.
*/
bool System::checkSDCviaCRC32(WD &wd){
	bool result = false;
	if(_crcParam){
		for (unsigned int index = 0; index < wd.getNumCopies(); index++) {
			if (wd.getCopies()[index].isInput()) {
				CopyData cd = wd.getCopies()[index];
				unsigned int computedCRC = 0xFFFFFFFF;
				size_t len = cd.getSize();
				void *buffer = (void*) cd.getAddress();////
				uint64_t key = cd.getAddress().value();
				if(cd.getNumDimensions()>1){
					for (unsigned int i = 0; i < cd.getDimensions()[1].accessed_length; i += 1){
							uint64_t address = cd.getAddress().value() + cd.getDimensions()[0].accessed_length * i;
							buffer = (void *) address;
							len =  cd.getDimensions()[0].accessed_length;
							computedCRC = sys.compute_Crc32(computedCRC, buffer, len);
					}
				}else{
					computedCRC = sys.compute_Crc32(computedCRC, buffer, len);
				}
				unsigned int storedCRC = getCRC32(key);
				//std::cerr << "Computed CRC "<<computedCRC << " vs. Stored CRC "<<storedCRC<<std::endl;
				if(storedCRC == 0){
					setCRC32(key,computedCRC);
					continue;
				}
				if(storedCRC != computedCRC){
					setCRC32(key, computedCRC);
					result = true;
				}
			}
		}
	}
	else{
			for (unsigned int index = 0; index < wd.getNumCopies(); index++) {
					if (wd.getCopies()[index].isInput()) {
						CopyData cd = wd.getCopies()[index];
						unsigned int computedCRC = 0xFFFFFFFF;
						size_t len = cd.getSize();
						void *buffer = (void*) cd.getAddress();
						uint64_t key = cd.getAddress().value();
						if(cd.getNumDimensions()>1){
							for (unsigned int i = 0; i < cd.getDimensions()[1].accessed_length; i += 1){
									uint64_t address = cd.getAddress().value() + cd.getDimensions()[0].accessed_length * i;
									buffer = (void *) address;
									len =  cd.getDimensions()[0].accessed_length;
									computedCRC = sys.compute_Crc32_Software(computedCRC, buffer, len);
							}
						}else{
							computedCRC = sys.compute_Crc32_Software(computedCRC, buffer, len);
						}
						unsigned int storedCRC = getCRC32(key);
						//std::cerr << "Computed CRC "<<computedCRC << " vs. Stored CRC "<<storedCRC<<std::endl;
						if(storedCRC == 0){
							setCRC32(key,computedCRC);
							continue;
						}
						if(storedCRC != computedCRC){
							setCRC32(key, computedCRC);
							result = true;
						}
					}
				}
	}
	//std::cerr <<"Does SDC Check Pass "<<result<<std::endl;
	return result;
}
/*!
* \brief Restores the WD wd if some SDCs are detected.
* \param wd The task whose state is to be restored.
*
*/
void System::restore(WD &wd) {
	//std::cerr << "Restoring Task "<<wd.getId()<<std::endl;
   debug ( "Resiliency CRC: Task ", wd.getId(), " is being recovered to be re-executed further on.");
   // Wait for successors to finish.
   //wd.waitCompletion();

   // Restore the data
   wd._mcontrol.restoreBackupData();

   while ( !wd._mcontrol.isDataRestored( wd ) ) {
      myThread->idle();
   }
   debug ( "Resiliency: Task ", wd.getId(), " recovery complete.");
   // Reset invalid state
   //wd.setInvalid(false);
}
