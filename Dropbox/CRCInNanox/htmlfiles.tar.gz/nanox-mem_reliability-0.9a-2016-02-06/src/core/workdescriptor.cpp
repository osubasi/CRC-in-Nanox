/*************************************************************************************/
/*      Copyright 2015 Barcelona Supercomputing Center                               */
/*                                                                                   */
/*      This file is part of the NANOS++ library.                                    */
/*                                                                                   */
/*      NANOS++ is free software: you can redistribute it and/or modify              */
/*      it under the terms of the GNU Lesser General Public License as published by  */
/*      the Free Software Foundation, either version 3 of the License, or            */
/*      (at your option) any later version.                                          */
/*                                                                                   */
/*      NANOS++ is distributed in the hope that it will be useful,                   */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of               */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                */
/*      GNU Lesser General Public License for more details.                          */
/*                                                                                   */
/*      You should have received a copy of the GNU Lesser General Public License     */
/*      along with NANOS++.  If not, see <http://www.gnu.org/licenses/>.             */
/*************************************************************************************/

#include "workdescriptor.hpp"
#include "schedule.hpp"
#include "processingelement.hpp"
#include "basethread.hpp"
#include "debug.hpp"
#include "schedule.hpp"
#include "system.hpp"
#include "os.hpp"
#include "synchronizedcondition.hpp"
#include "basethread.hpp"

using namespace nanos;

/*! \brief This class identifies a single unit of work
 *
 * A slicible WorkDescriptor defines an specific behaviour which potentially can divide a WorkDescriptor
 * in smaller WorkDescriptor's
 *
 * The main idea behind this behaviour is to offer a mechanism which allow to decompose a WorkDescriptor in a
 * set of several WorkDescriptors. Initial implementation of this mechanism is related with the
 * ticket:96.
 *
 * A slicible WordDescriptor will be always related with:
 *
 * - a Slicer, which defines the work descriptor behaviour.
 * - a SlicerData, which keeps all the data needed for splitting the work.
 * - Slicer objects are common for all the slicible WordDescriptor of an specific type. In fact, the Slicer object
 *   determines the type of the slicible WordDescriptor. In the other hand, SlicerData objects are individual for
 *   each slicible WordDescriptor object.
 *
 * A slicible WordDescriptor modifies the behaviour of submit() and dequeue() methods.
 *
 * The common behaviour of a WorkDescriptor submit() method just call Scheduller::submit() method and dequeue() returns
 * the WD itself (meaning this is the work unit ready to be executed) and a boolean value (true,
 * meaning that it will be the last execution for this unit of work). Otherwise, slicible WordDescriptor will execute
 * Slicer::submit() and Slicer::dequeue() respectively, giving the slicer the responsibility of doing specific actions
 * at submission or dequeuing time.
 *
 */
   class WorkDescriptor
   {}

/*!
 * \brief Invokes the starting of the CRC-32 of calculation of the produced output.
 */
void WorkDescriptor::finish ()
{
   // Getting run time
   _runTime = ( sys.getDefaultSchedulePolicy()->isCheckingWDRunTime() ? OS::getMonotonicTimeUs() - _runTime : 0.0 );

   // At that point we are ready to copy data out
   if ( getNumCopies() > 0 ) {
      _mcontrol.copyDataOut( MemController::WRITE_BACK );
      while ( !_mcontrol.isOutputDataReady( *this ) ) {
         myThread->processTransfers();
      }
   }

   if(sys._crc_enabled){
	   sys.startComputeCRC(*this);
   }

   // Getting execution time
   _executionTime = ( _numDevices == 1 ? 0.0 : OS::getMonotonicTimeUs() - _executionTime );
}





